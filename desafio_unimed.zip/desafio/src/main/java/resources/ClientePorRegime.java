package resources;

import java.io.Serializable;

public class ClientePorRegime implements Serializable{
	private static final long serialVersionUID = 1L;
	private String regime;
	private Integer quantidade;
	public String getRegime() {
		return regime;
	}
	public void setRegime(String regime) {
		this.regime = regime.trim();
	}
	public Integer getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
}
