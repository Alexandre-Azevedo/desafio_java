package regras;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import resources.ClientePorRegime;
import resources.Empresa;

public class DesafioAS implements Serializable{
	private static final long serialVersionUID = 1L;

	public List<Empresa> removerEmpresa(Empresa empresa, List<Empresa> empresas) {	
		List<Empresa> empresasAuxiliar = new ArrayList<>();
		for(Empresa registroAtual : empresas) {
			if(!condicaoBusca(empresa, registroAtual)) {
				empresasAuxiliar.add(registroAtual);
			}
		}
		return empresasAuxiliar;
	}
	
	public List<Empresa> buscarEmpresa(Empresa empresa, List<Empresa> empresas) {
		List<Empresa> busca = new ArrayList<>();
		for(Empresa registroAtual : empresas) {
			if(condicaoBusca(empresa, registroAtual)) {
				busca.add(registroAtual);
			}
		}
		return busca;
	}
	
	public Boolean condicaoBusca(Empresa empresa, Empresa registroAtual) {
		return (empresa.getRazaoSocial().equals(registroAtual.getRazaoSocial())
				&& empresa.getCnpj().equals(registroAtual.getCnpj())
				&& empresa.getEmail().equals(registroAtual.getEmail())
				&& empresa.getRegime().equals(registroAtual.getRegime()));
	}
	
	
	public List<Integer> contarEmpresas(List<Empresa> empresas){
		List<Integer> quantidade = new ArrayList<>();
		quantidade.add(empresas.size());
		return quantidade;
	}
	
	public List<ClientePorRegime> contarPorRegime(List<Empresa> empresas){
		List<ClientePorRegime> clientesPorRegime = new ArrayList<>();
		ClientePorRegime simplesNacional = new ClientePorRegime();
		Integer countSimplesNacional = 0;
		ClientePorRegime lucroPresumido = new ClientePorRegime();
		Integer countLucroPresumido = 0;
		simplesNacional.setRegime("Simples Nacional");
		lucroPresumido.setRegime("Lucro Presumido");
		for(Empresa empresa : empresas) {
			if(empresa.getRegime().equals(simplesNacional.getRegime())) {
				countSimplesNacional = countSimplesNacional + 1;
			}
			if(empresa.getRegime().equals(lucroPresumido.getRegime())) {
				countLucroPresumido = countLucroPresumido + 1;
				
			}
		}
		simplesNacional.setQuantidade(countSimplesNacional);
		lucroPresumido.setQuantidade(countLucroPresumido);
		clientesPorRegime.add(simplesNacional);
		clientesPorRegime.add(lucroPresumido);
		
		return clientesPorRegime;
		
	}

}
