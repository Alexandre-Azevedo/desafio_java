package meneagedbean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import regras.DesafioAS;
import resources.ClientePorRegime;
import resources.Empresa;

@Named
@SessionScoped
public class DesafioMB implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Empresa empresa;
	@Inject
	private DesafioAS desafioAS;
	
	
	
	private List<Empresa> empresas = new ArrayList<>();
	private List<Empresa> busca = new ArrayList<>();
	private List<Empresa> posRemocao = new ArrayList<>();
	private List<Integer> quantidade = new ArrayList<>();
	private List<ClientePorRegime> clientesPorRegime = new ArrayList<>(); 
	
	private Boolean form1 = false;
	private Boolean form2 = false;
	private Boolean form3 = true;
	private Boolean form4 = false;
	private Boolean form5 = false;
	private Boolean form6 = false;
	private Integer dashboard;
	
	
	
	private void limpar() {
		empresa = new Empresa();
		dashboard = 0;
	}

	public Empresa getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	public List<Empresa> getEmpresas() {
		return empresas;
	}

	public void setEmpresas(List<Empresa> empresas) {
		this.empresas = empresas;
	}

	public List<Empresa> getBusca() {
		return busca;
	}

	public void setBusca(List<Empresa> busca) {
		this.busca = busca;
	}

	public List<Empresa> getPosRemocao() {
		return posRemocao;
	}

	public void setPosRemocao(List<Empresa> posRemocao) {
		this.posRemocao = posRemocao;
	}

	public List<Integer> getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(List<Integer> quantidade) {
		this.quantidade = quantidade;
	}

	public List<ClientePorRegime> getClientesPorRegime() {
		return clientesPorRegime;
	}

	public void setClientesPorRegime(List<ClientePorRegime> clientesPorRegime) {
		this.clientesPorRegime = clientesPorRegime;
	}

	public Integer getDashboard() {
		return dashboard;
	}

	public void setDashboard(Integer dashboard) {
		this.dashboard = dashboard;
	}

	public Boolean getForm1() {
		return form1;
	}

	public void setForm1(Boolean form1) {
		this.form1 = form1;
	}

	public Boolean getForm2() {
		return form2;
	}

	public void setForm2(Boolean form2) {
		this.form2 = form2;
	}

	public Boolean getForm3() {
		return form3;
	}

	public void setForm3(Boolean form3) {
		this.form3 = form3;
	}

	public Boolean getForm4() {
		return form4;
	}

	public void setForm4(Boolean form4) {
		this.form4 = form4;
	}

	public Boolean getForm5() {
		return form5;
	}

	public void setForm5(Boolean form5) {
		this.form5 = form5;
	}

	public Boolean getForm6() {
		return form6;
	}

	public void setForm6(Boolean form6) {
		this.form6 = form6;
	}

	public void cliqueCadastrar() {
		empresas.add(empresa);
		limpar();
		
		setForm1(false);
		setForm2(false);
		setForm3(true);
		setForm5(false);
		setForm6(false);
		
	}
	
	public void cliqueListarClientes() {
		limpar();
		setForm1(false);
		setForm2(false);
		setForm3(true);
		setForm5(false);
		setForm6(false);
	}
	
	public void cliqueRemover() {
		empresas = desafioAS.removerEmpresa(getEmpresa(), getEmpresas());
		limpar();
		
		setForm1(false);
		setForm2(false);
		setForm3(false);
		setForm5(true);
		setForm6(false);
	}
	
	public void cliqueBuscar() {
		busca = desafioAS.buscarEmpresa(getEmpresa(), getEmpresas());
		limpar();
		
		setForm1(false);
		setForm2(false);
		setForm3(false);
		setForm5(false);
		setForm6(true);
	}
	
	public void cliqueDashboards() {
		if (dashboard == null){
			limpar();
		}else {
			if (dashboard == 2) {
				clientesPorRegime = desafioAS.contarPorRegime(empresas);
				limpar();
				setForm1(false);
				setForm2(true);
				setForm3(false);
				setForm5(false);
				setForm6(false);
			}else if (dashboard == 1) {
				quantidade = desafioAS.contarEmpresas(empresas);
				limpar();
				setForm1(true);
				setForm2(false);
				setForm3(false);
				setForm5(false);
				setForm6(false); 
			}
		}
	}
	
	
	
	
	
}
